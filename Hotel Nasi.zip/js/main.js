// for links

var state = false;
var bar = document.getElementById('links');
var btn = document.getElementById('menu-btn');
var body = document.getElementById('body')
var theme_btn = document.getElementById('theme');


btn.addEventListener('click', function() {
  if (state) {
    bar.classList = 'none links';
    state = false;
  } else {
    bar.classList = 'block links';
    state = true;
  }
});

theme_btn.addEventListener('click', function() {
  if (state) {
    body.classList = 'light';
    theme_btn.innerText ='Dark Theme'
    state = false;
  } else {
    body.classList = 'dark';
    theme_btn.innerText ='Light Theme'
    state = true;
  }
});
